import matplotlib.pyplot as plt
import matplotlib.animation as animation
import os
import numpy as np

dat_files = [("sqrt.dat", "fast_sqrt()"), ("sqrt2.dat", "sqrt()"), ("sqrt3.dat", "herons_method()")]


MAX_FRAMES = 300

def load_data(filename, max_points=MAX_FRAMES):
    x_vals = []
    y_vals = []
    with open(filename, "r") as f:
        for line in f:
            if "::" in line:
                left, right = line.strip().split("::")
                x_vals.append(int(left.strip()))
                y_vals.append(float(right.strip()))

    if len(y_vals) > max_points:
        target_times = np.linspace(0, 1.0, max_points)
        resampled_x = []
        reasmpled_y = []

        idx = 0
        for t in target_times:
            while idx < len(y_vals) - 1 and y_vals[idx] < t:
                idx += 1
            resampled_x.append(x_vals[idx])
            resampled_y.append(y_vals[idx])

        x_vals, y_vals = resampled_x, resampled_y

    return x_vals, y_vals

datasets = [load_data(file) for file, _ in dat_files]

fig, ax = plt.subplots()
ax.set_xlim(0, max(max(x_vals) for x_vals, _ in datasets)*1.05)
ax.set_ylim(0, 1.05)
ax.set_xlabel("Square roots computed")
ax.set_ylabel("Elapsed time (s)")

lines = [ax.plot([], [], label=label, lw=2)[0] for _, label in dat_files]
ax.legend(loc="lower right", fontsize=12)

def update(frame):
    for i, (xs, ys) in enumerate(datasets):
        if frame < len(xs):
            lines[i].set_data(xs[:frame], ys[:frame])
    return lines

ani = animation.FuncAnimation(
    fig, update, frames=MAX_FRAMES, interval=1000 * 10 / MAX_FRAMES, blit=True
)

ani.save("flushing_comparsion.gif", writer="pillow", fps=30)
