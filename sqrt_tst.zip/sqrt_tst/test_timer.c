#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <pthread.h>
#include <math.h>
#include "sqrt.c"


#define LIMIT_SEC (1.0)
#define SAMPLE_INTERVAL (10000000)

int main(){

    struct timespec start, now;
    clock_gettime(CLOCK_MONOTONIC, &start);

    uint64_t i = 1;
    int data_points = 0;
    uint64_t next_sample = SAMPLE_INTERVAL;

    FILE *out = fopen("sqrt1.dat", "w");

    float result;

    while (1){
        result = herons_method((float)i);
        i++;

        if(i >= next_sample){
            clock_gettime(CLOCK_MONOTONIC, &now);

            double elapsed = (now.tv_sec - start.tv_sec)+(now.tv_nsec-start.tv_nsec) / 1e9;

            if (elapsed >= LIMIT_SEC) break;

            fprintf(out, "%llu :: %.9f\n", (unsigned long long)i, elapsed);
            printf("%llu :: %.9f\n", (unsigned long long)i, elapsed);
            next_sample += SAMPLE_INTERVAL;
            data_points++;
        }
    }

    fclose(out);
    printf("%lf", result);

    clock_gettime(CLOCK_MONOTONIC, &now);

    return 0;
}
    
