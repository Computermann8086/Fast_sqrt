static inline float fast_sqrt(float n){
    float est = n;
    long nf;

    nf = *(long*)&est;         // Make it a long, so we can actually do shit with the bits
    nf = (((nf >> 1)<<23)-0x3F7A7EFA)^0x80000000U;   // Why does this even work?
    est = *(float*)&nf;
    est = 0.5F*(est+(n/est)); // Two iterations of Newtons Method
    est = 0.5F*(est+(n/est)); // Here's the seccond one
    return est;
}


float herons_method(float s){
    float initial_estimate = s/2;
    float current_step = initial_estimate;
    float epsilon = s * 1e-9f;

    while (1) {
        float next_step = ((float)1/2)*(current_step + (s/current_step));
        if (fabs(next_step - current_step) < epsilon) {
            break;
        }
        current_step = next_step;
    }
    return current_step;
}
